import cv2
import numpy as np
import matplotlib.pyplot as plt

def increase_contrast(image, alpha=1.5, beta=0):
    # Apply contrast enhancement using brightness and contrast adjustment
    adjusted_image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
    return adjusted_image

def reduce_brightness(image, value=30):
    # Convert image to HLS color space
    hls_image = cv2.cvtColor(image, cv2.COLOR_BGR2HLS)

    # Reduce brightness (lightness) by subtracting a constant value
    hls_image[:, :, 1] = np.clip(hls_image[:, :, 1] - value, 0, 255)

    # Convert back to BGR color space
    brightness_reduced_image = cv2.cvtColor(hls_image, cv2.COLOR_HLS2BGR)

    return brightness_reduced_image

def plot_histograms(original_image, processed_image=None):
    # Calculate histograms for each channel
    original_hist_red = cv2.calcHist([original_image], [0], None, [256], [0, 256])
    original_hist_green = cv2.calcHist([original_image], [1], None, [256], [0, 256])
    original_hist_blue = cv2.calcHist([original_image], [2], None, [256], [0, 256])

    original_hist_red = original_hist_red.ravel()
    original_hist_green = original_hist_green.ravel()
    original_hist_blue = original_hist_blue.ravel()

    if processed_image is not None:
        processed_hist_red = cv2.calcHist([processed_image], [0], None, [256], [0, 256])
        processed_hist_green = cv2.calcHist([processed_image], [1], None, [256], [0, 256])
        processed_hist_blue = cv2.calcHist([processed_image], [2], None, [256], [0, 256])

        processed_hist_red = processed_hist_red.ravel()
        processed_hist_green = processed_hist_green.ravel()
        processed_hist_blue = processed_hist_blue.ravel()

    # Plot histograms
    plt.figure(figsize=(15, 5))

    plt.subplot(1, 2, 1)
    plt.plot(original_hist_red, color='red', label='Red')
    plt.plot(original_hist_green, color='green', label='Green')
    plt.plot(original_hist_blue, color='blue', label='Blue')
    plt.title('Original Image Histogram')
    plt.xlabel('Pixel Value')
    plt.ylabel('Frequency')
    plt.legend()

    if processed_image is not None:
        plt.subplot(1, 2, 2)
        plt.plot(processed_hist_red, color='red', label='Red')
        plt.plot(processed_hist_green, color='green', label='Green')
        plt.plot(processed_hist_blue, color='blue', label='Blue')
        plt.title('Processed Image Histogram')
        plt.xlabel('Pixel Value')
        plt.ylabel('Frequency')
        plt.legend()

    plt.show()

# Load the image
image_path = 'test.jpg'
image = cv2.imread(image_path)

# Increase contrast
contrast_increased_image = increase_contrast(image)

# Reduce brightness
brightness_reduced_image = reduce_brightness(contrast_increased_image)

# Display the original and processed images
cv2.imshow('Original Image', image)
cv2.imshow('Processed Image', brightness_reduced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Plot histogram of processed image
plot_histograms(image, brightness_reduced_image)