import keyboard  # Import keyboard library for detecting keypress events  
import subprocess  # Import subprocess module for running system commands  
import time
while True:
  time.sleep(1)
  if keyboard.is_pressed('x'):
    break
    # Break out of infinite loop when 'X' is pressed
print("PC has been stunned.")
process = subprocess.Popen(["systemctl", "stop", "lightdm"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
output, error = process.communicate()
if error != b"":
  print(error)
else:
  print("System stopped successfully.")